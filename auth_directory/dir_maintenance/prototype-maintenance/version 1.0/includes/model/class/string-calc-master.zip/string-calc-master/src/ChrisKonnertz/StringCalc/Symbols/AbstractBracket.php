<?php

namespace ChrisKonnertz\StringCalc\Symbols;

/**
 * This is the parent class for both bracket types:
 * Closing and opening brackets.
 *
 * @package ChrisKonnertz\StringCalc\Symbols
 */
class AbstractBracket extends AbstractSymbol
{

}