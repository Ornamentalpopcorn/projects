<?php

namespace ChrisKonnertz\StringCalc\Symbols\Concrete\Brackets;

use ChrisKonnertz\StringCalc\Symbols\AbstractOpeningBracket;

class OpeningBracket extends AbstractOpeningBracket
{

    protected $identifiers = ['('];

}